# MERN Task Manager
Run `npm install` in both backend and frontend folders.