
# MERN Task Manager 📝

A simple full-stack Task Management app built with the **MERN stack**:
- **MongoDB** – NoSQL database
- **Express.js** – Web framework for Node.js
- **React.js** – Frontend UI
- **Node.js** – Backend runtime

## ✨ Features
- Create tasks
- Read all tasks
- Update task completion
- Delete tasks

## 📁 Folder Structure
```
mern-taskmanager/
├── backend/        # Node.js + Express + MongoDB backend
├── frontend/       # React frontend
```

## 🚀 Getting Started

### Prerequisites
- Node.js
- MongoDB

### 1. Clone the repository
```bash
git clone https://github.com/yourusername/mern-taskmanager.git
cd mern-taskmanager
```

### 2. Run the backend
```bash
cd backend
npm install
node server.js
```

### 3. Run the frontend
```bash
cd frontend
npm install
npm start
```

The app runs on `http://localhost:3000` and connects to backend `http://localhost:5000`.

## 📝 License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
