
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    const res = await axios.get('http://localhost:5000/tasks');
    setTasks(res.data);
  };

  const createTask = async () => {
    const res = await axios.post('http://localhost:5000/tasks', { title: newTask });
    setTasks([...tasks, res.data]);
    setNewTask("");
  };

  const deleteTask = async (id) => {
    await axios.delete(`http://localhost:5000/tasks/${id}`);
    setTasks(tasks.filter(task => task._id !== id));
  };

  const toggleTask = async (task) => {
    const res = await axios.put(`http://localhost:5000/tasks/${task._id}`, { ...task, completed: !task.completed });
    setTasks(tasks.map(t => t._id === task._id ? res.data : t));
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Task Manager</h1>
      <input value={newTask} onChange={e => setNewTask(e.target.value)} />
      <button onClick={createTask}>Add</button>
      <ul>
        {tasks.map(task => (
          <li key={task._id}>
            <span style={{ textDecoration: task.completed ? 'line-through' : 'none' }}
                  onClick={() => toggleTask(task)}>{task.title}</span>
            <button onClick={() => deleteTask(task._id)}>X</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
